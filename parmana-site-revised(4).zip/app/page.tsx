import Hero from "@/components/Hero";
import VisionMission from "@/components/VisionMission";
import Problem from "@/components/Problem";
import Gap from "@/components/Gap";
import Solution from "@/components/Solution";
import HowItWorks from "@/components/HowItWorks";
import ExistingInfrastructure from "@/components/ExistingInfrastructure";
import Evidence from "@/components/Evidence";
import Architecture from "@/components/Architecture";
import TechGuarantees from "@/components/TechGuarantees";
import UseCases from "@/components/UseCases";
import DemoTeaser from "@/components/DemoTeaser";
import Stakeholders from "@/components/Stakeholders";
import FAQ from "@/components/FAQ";
import BottomCTA from "@/components/BottomCTA";
import Reveal from "@/components/Reveal";

export default function Home() {
  return (
    <main>
      <Hero />
      <Reveal><VisionMission /></Reveal>
      <Reveal><Problem /></Reveal>
      <Reveal><Gap /></Reveal>
      <Reveal><Solution /></Reveal>
      <Reveal><HowItWorks /></Reveal>
      <Reveal><ExistingInfrastructure /></Reveal>
      <Reveal><Evidence /></Reveal>
      <Reveal><Architecture /></Reveal>
      <Reveal><TechGuarantees /></Reveal>
      <Reveal><UseCases /></Reveal>
      <Reveal><DemoTeaser /></Reveal>
      <Reveal><Stakeholders /></Reveal>
      <Reveal><FAQ /></Reveal>
      <Reveal><BottomCTA /></Reveal>
    </main>
  );
}
