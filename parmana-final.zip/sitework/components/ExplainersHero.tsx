export default function ExplainersHero() {
  return (
    <section className="relative overflow-hidden bg-paper border-b border-border">
      <div className="relative max-w-container mx-auto px-6 py-16 md:py-20 lg:py-24 text-center">
        <p className="text-xs font-mono uppercase tracking-wide text-purple-deep">Simple explanations</p>
        <h1 className="mx-auto mt-4 max-w-[720px] text-[30px] md:text-[42px] font-bold leading-[1.15] tracking-tight text-ink">
          Understand the problem in a few minutes.
        </h1>
        <p className="mx-auto mt-6 max-w-[640px] text-lg leading-[1.5] text-ink/70">
          Simple explanations of what changes when AI starts doing more work—and how a business can keep control.
        </p>
      </div>
    </section>
  )
}
