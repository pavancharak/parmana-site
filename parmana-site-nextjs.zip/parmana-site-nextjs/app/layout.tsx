import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Parmana Systems | Keep the authority. Let AI operate autonomously.",
  description:
    "Parmana ensures autonomous AI can execute only the actions your business has authorized.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
