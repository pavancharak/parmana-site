"use client";

import { useState } from "react";

const examples = [
  ["Refunds", "AI can decide that a refund is appropriate. Parmana checks whether that refund is within the authority the business granted before it executes."],
  ["Payments", "AI can choose a vendor and prepare a payment. Parmana verifies that the amount, vendor and action are within the business rules before execution."],
  ["Customer records", "AI can work with customer information. Parmana prevents execution when the requested action falls outside the access the business granted."]
];

export default function ParmanaWebsite() {
  const [selected, setSelected] = useState(0);

  return (
    <>
      <header className="container nav">
        <a className="logo" href="#">PARMANA</a>
        <nav className="navlinks">
          <a href="#how">How it works</a>
          <a href="#examples">Examples</a>
          <a href="#institutions">For institutions</a>
        </nav>
        <a className="btn btn-dark" href="#contact">Talk to us</a>
      </header>

      <main>
        <section className="container hero">
          <div className="eyebrow">Execution authority for autonomous AI</div>
          <h1>Keep the authority. Let AI operate autonomously.</h1>
          <p className="lead">
            Parmana ensures autonomous AI can execute only the actions your business has authorized.
          </p>
          <div className="actions">
            <a className="btn btn-dark" href="#how">See how it works</a>
            <a className="btn btn-light" href="#examples">See real examples</a>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className="eyebrow">The gap</div>
            <h2>Accountability without authority is a dangerous gap.</h2>
            <p>
              Businesses can define rules, review AI decisions and monitor what happened.
              But none of that is enough if an autonomous system can still execute an action
              the business never authorized.
            </p>
            <div className="quote">AI may operate autonomously. It must never become the authority.</div>
          </div>
        </section>

        <section className="section" id="how">
          <div className="container">
            <div className="eyebrow">How Parmana works</div>
            <h2>The business keeps the authority. AI gets room to operate.</h2>
            <div className="flow">
              {[
                ["01", "Business defines authority", "The institution decides what AI is allowed to execute."],
                ["02", "AI operates", "The AI agent plans and acts autonomously."],
                ["03", "Parmana checks", "Every attempted execution is checked against the granted authority."],
                ["04", "Only authorized actions execute", "Outside the boundary, execution is blocked."]
              ].map(([n,t,p]) => (
                <div className="step" key={n}><span>{n}</span><strong>{t}</strong><p>{p}</p></div>
              ))}
            </div>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className="eyebrow">The distinction</div>
            <h2>Autonomy is not authority.</h2>
            <div className="compare">
              <div className="bad">
                <strong>Autonomous AI without an enforced boundary</strong>
                <p>AI can make decisions, call systems and trigger actions. The business may discover later that something happened outside its intent.</p>
              </div>
              <div>
                <strong>Autonomous AI with Parmana</strong>
                <p>AI remains free to operate, but execution stays inside the authority the institution granted.</p>
              </div>
            </div>
          </div>
        </section>

        <section className="section" id="examples">
          <div className="container">
            <div className="eyebrow">Real world</div>
            <h2>What this means in practice.</h2>
            <div className="grid">
              {examples.map(([title, text], i) => (
                <button key={title} className="card" style={{textAlign:"left", cursor:"pointer"}} onClick={() => setSelected(i)}>
                  <h3>{title}</h3>
                  <p>{text}</p>
                </button>
              ))}
            </div>
            <div className="quote">{examples[selected][1]}</div>
          </div>
        </section>

        <section className="section" id="institutions">
          <div className="container">
            <div className="eyebrow">Built for institutions</div>
            <h2>Designed for businesses that cannot hand their authority to an autonomous system.</h2>
            <div className="grid">
              {["Banking and financial services", "Insurance and healthcare", "Enterprise operations"].map((x) => (
                <div className="card" key={x}><h3>{x}</h3><p>Keep business authority explicit while allowing AI to operate at machine speed.</p></div>
              ))}
            </div>
          </div>
        </section>

        <section className="section" id="contact">
          <div className="container">
            <div className="eyebrow">Parmana Systems</div>
            <h2>Let AI operate. Keep the authority.</h2>
            <p>Parmana is built for institutions that want autonomous AI without giving up control over what their systems can actually execute.</p>
            <div className="actions"><a className="btn btn-dark" href="mailto:founder@parmanasystems.com">Talk to Parmana</a></div>
          </div>
        </section>
      </main>

      <footer className="container footer">
        © {new Date().getFullYear()} Parmana Systems. Autonomous operation. Business authority.
      </footer>
    </>
  );
}
